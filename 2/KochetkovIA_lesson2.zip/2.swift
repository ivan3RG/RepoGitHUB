import Foundation

func division3(n:Int = 0) -> Bool{
    if n % 3 == 0{
        return true
    }else{
        return false
    }
}

var a = even(n: )
print(a)
