import Foundation

func even(n:Int = 0) -> Bool{
    if n % 2 == 0{
        return true
    }else{
        return false
    }
}

var a = even(n: )
print(a)
